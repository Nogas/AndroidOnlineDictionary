# Android Online Dictionary
Simple Android Online Dictionary Download Json file from your server show in the list and its searchable

its beta version - student projects
