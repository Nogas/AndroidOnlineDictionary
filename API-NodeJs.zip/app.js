const fs = require('fs');
const bodyParser = require('body-parser');
const express = require('express');
var app = express();

var urlencodedParser = bodyParser.urlencoded({
    extended: false
});

app.use('/public', express.static(process.cwd() + '/public')); // app.use(express.static(__dirname + '/public'));

app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    res.render('pages/register', {
        "send": 0
    });
});

app.post('/', urlencodedParser, (req, res) => {
    var info = {};
    info["word"] = req.body.word;
    info["mining"] = req.body.mining;

    // var info = {word: [], mining: []};
    // info.word.push(req.body.word);
    // info.mining.push(req.body.mining);

    // var data = fs.readFileSync('register.json');
    // info = JSON.parse(data);
    // info.word.push({word: req.body.word});
    // info.mining.push({mining: req.body.mining});

    // fs.writeFile("register.json", JSON.stringify(info));

    fs.appendFileSync('register.json', JSON.stringify(info));
    
    res.render('pages/register', {
        "send": 1
    });
});

app.get('/api', (req, res) => {
    fs.readFile('register.json', 'utf8', (err, data) => {
        res.send(JSON.parse(data));
    });
});

app.get('/about', (req, res) => {
        res.render('pages/about');
});

app.listen(3000, () => {
    console.log("App running on 3000");
});